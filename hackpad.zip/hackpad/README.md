# Color Merge Hackpad

## Merge together LED colors

A little game where each key press can merge the colors displayed on the leds. Try to get to the max color without filling up all the leds and running out of moves!